
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Persona;
import models.PersonaDAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Esta clase permite traer desde la página registrar.jsp los datos ingresados en dicha página mediante su único método (doPost), para luego enviar estos datos a la tabla de la base de datos mediante el método agregar de la clase PersonaDAO.
 * @author santiago.jaramillo12
 * 
 */
@WebServlet(urlPatterns = {"/AdminPersona"})
public class AdminPersona extends HttpServlet { 
    
    PersonaDAO perDAO = new PersonaDAO();
    Persona per = new Persona();
    /**
     * Este método se encarga de tomar del formulario de la página de registrar.jsp los datos necesarios para crear un objeto Persona y ejecuta el método agregar(Persona p) de la clase PersonaDAO para insertar dichos datos en la tabla de la base de datos.
     * @param request 
     * @param response
     * @throws ServletException
     * @throws IOException 
     */  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int edad = parseInt(request.getParameter("edad"));
        String trabaja = request.getParameter("trabaja");
        String estado = request.getParameter("estado");
        int id = parseInt(request.getParameter("id"));
        int puntaje = parseInt(request.getParameter("puntaje"));
        
        per.setTrabaja(trabaja);
        per.setEdad(edad);
        per.setId(id);
        per.setEstado(estado);
        per.setPuntaje(puntaje);
        perDAO.agregar(per);

        RequestDispatcher view = request.getRequestDispatcher("registrar.jsp");
        request.setAttribute("mensaje", "Persona agregada satisfactoriamente");
        view.forward(request, response);
    }

}