/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;
import com.mysql.jdbc.Connection;
import db.DB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import models.Persona;

/**
 * Esta clase sirve para hacer operaciones sobre la tabla de la base de datos, las cuales son agregar y obtener los datos en la tabla.
 * @author Santiago
 */
public class PersonaDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    DB conexion = null;
/**
 * Este método se encarga de insertar los atributos de un objeto Persona en la base de datos.
 * @param p es el objeto Persona del cual se extraeran los datos a insertar en la base de datos.
 */
    public void agregar(Persona p) {

        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query = "INSERT INTO persona (edad, trabaja, estado, id, puntaje) values (?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, p.getEdad()); 
            ps.setString(2, p.getTrabaja()); 
            ps.setString(3, p.getEstado());
            ps.setInt(4, p.getId());
            ps.setInt(5, p.getPuntaje());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        } finally { try { rs.close(); } catch (Exception e) { /* ignored */ }
        }
    }
    /**
     * Este método sirve para extraer los datos de la tabla 'persona' de la base de datos.
     * @return Un ArrayList de objetos Persona con los datos extraidos de la base de datos.
     */
    public ArrayList<Persona> obtenerPersonas() {
        ArrayList<Persona> personas = new ArrayList<Persona>();
        try {
            conn = DB.getConexion();
            String query = "SELECT * FROM persona ORDER BY puntaje DESC";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Persona persona = new Persona();
                persona.setEdad(rs.getInt("edad"));
                persona.setEstado(rs.getString("estado"));
                persona.setTrabaja(rs.getString("trabaja"));
                persona.setId(rs.getInt("id"));
                persona.setPuntaje(rs.getInt("puntaje"));
                personas.add(persona);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return personas;
    }
    
}
