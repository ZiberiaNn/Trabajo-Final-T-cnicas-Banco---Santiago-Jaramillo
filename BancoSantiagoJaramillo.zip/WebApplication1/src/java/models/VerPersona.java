/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Esta clase permite acceder desde la página mostrar.jsp a su único método (doPost), con el fin de extraer los datos de la tabla de la base de datos (mediante el método obtenerPersonas de la clase PersonaDAO) y mostrarlos en la página.
 * @author Santiago
 */
@WebServlet(urlPatterns = {"/VerPersona"})
public class VerPersona extends HttpServlet { 
    
    PersonaDAO perDAO = new PersonaDAO();
    Persona per = new Persona();
    ArrayList<Persona> personas;
    /**
     * Este método se encarga de usar el método obtenerPersonas() de la clase PersonaDAO para extraer los datos de la tabla de la base de datos, dichos datos serán mostrados en la página mostrar.jsp
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException 
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException { 
        personas=perDAO.obtenerPersonas();

        RequestDispatcher view = request.getRequestDispatcher("mostrar.jsp");
        request.setAttribute("personas", personas);
        view.forward(request, response);
    } 


}
