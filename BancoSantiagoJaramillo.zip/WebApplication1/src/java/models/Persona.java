/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 * Esta clase será usada para crear objetos que guarden los datos de una fila de la tabla de la base de datos.
 * @author santiago.jaramillo12
 */
public class Persona {
    
    protected Integer edad;
    protected String trabaja;
    protected String estado;
    protected Integer id;
    protected Integer puntaje;

    public Integer getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(Integer puntaje) {
        this.puntaje = puntaje;
    }

    public String getTrabaja() {
        return trabaja;
    }
    public void setTrabaja(String trabaja) {
        this.trabaja = trabaja;
    }
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getEdad() { return edad; }
    public void setEdad(Integer edad) { this.edad = edad; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
}